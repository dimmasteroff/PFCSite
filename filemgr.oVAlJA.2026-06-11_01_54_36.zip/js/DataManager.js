/**
 * DataManager - управление JSON данными через localStorage
 * Все данные хранятся в localStorage и синхронизируются с /data/ папкой
 */

class DataManager {
  // Префикс для localStorage ключей
  static PREFIX = 'rfl_data_';

  /**
   * Загрузить данные из localStorage или инициализировать пустой массив
   * @param {string} dataType - тип данных (drivers, teams, calendar, results, news)
   * @returns {Array|Object} данные
   */
  static async load(dataType) {
    const key = `${this.PREFIX}${dataType}`;
    const stored = localStorage.getItem(key);

    if (stored) {
      try {
        return this.normalize(dataType, JSON.parse(stored));
      } catch (e) {
        console.error(`Ошибка парсинга ${dataType}:`, e);
        return this.normalize(dataType, this.getDefaultData(dataType));
      }
    }

    return this.normalize(dataType, this.getDefaultData(dataType));
  }

  /**
   * Сохранить данные в localStorage
   * @param {string} dataType - тип данных
   * @param {Array|Object} data - данные для сохранения
   */
  static async save(dataType, data) {
    const key = `${this.PREFIX}${dataType}`;
    const normalizedData = this.normalize(dataType, data);
    try {
      localStorage.setItem(key, JSON.stringify(normalizedData));
      console.log(`✓ ${dataType} сохранены`);

      // Отправить событие об изменении данных ДЛЯ ВСЕХ ВКЛАДОК
      window.dispatchEvent(new CustomEvent('dataUpdated', {
        detail: { dataType, data: normalizedData, timestamp: Date.now() }
      }));

      // Отправить через storage event для синхронизации между вкладками
      window.dispatchEvent(new StorageEvent('storage', {
        key: key,
        newValue: JSON.stringify(normalizedData),
        oldValue: null,
        storageArea: localStorage,
        url: window.location.href
      }));

      return true;
    } catch (e) {
      console.error(`Ошибка сохранения ${dataType}:`, e);
      return false;
    }
  }

  /**
   * Получить данные по умолчанию для каждого типа
   */
  static getDefaultData(dataType) {
    const defaults = {
      drivers: [],
      teams: [],
      calendar: { season: '2026', rounds: [] },
      news: [],
      standings: {
        drivers: [],
        constructors: []
      },
      results: {}
    };
    return defaults[dataType] || [];
  }

  /**
   * Имя пилота для отображения на публичных страницах и в админке.
   */
  static getDriverFullName(driver) {
    if (!driver) return 'N/A';
    const firstName = (driver.firstName || '').trim();
    const lastName = (driver.lastName || '').trim();
    const fullName = `${firstName} ${lastName}`.trim();
    return fullName || driver.name || 'N/A';
  }

  /**
   * URL логотипа команды с обратной совместимостью для старого поля logo.
   */
  static getTeamLogoUrl(team) {
    return team?.logoUrl || team?.logo || '../logos/pfcnewlogo.png';
  }

  /**
   * Нормализовать данные к актуальной JSON-структуре.
   */
  static normalize(dataType, data) {
    if (dataType === 'drivers') {
      return (Array.isArray(data) ? data : []).map(driver => {
        const [fallbackFirst = '', ...rest] = String(driver.name || '').trim().split(/\s+/).filter(Boolean);
        const firstName = (driver.firstName || fallbackFirst || '').trim();
        const lastName = (driver.lastName || rest.join(' ') || '').trim();
        const normalized = {
          ...driver,
          firstName,
          lastName,
          number: driver.number,
          teamId: driver.teamId || '',
          class: driver.class || 'F1',
          avatar: driver.avatar || driver.photo || `https://via.placeholder.com/150?text=${encodeURIComponent((firstName || 'PFC').slice(0, 3))}`,
          stats: {
            points: 0,
            wins: 0,
            podiums: 0,
            fastestLaps: 0,
            ...(driver.stats || {})
          }
        };
        delete normalized.name;
        delete normalized.photo;
        return normalized;
      });
    }

    if (dataType === 'teams') {
      return (Array.isArray(data) ? data : []).map(team => {
        const normalized = {
          ...team,
          logoUrl: team.logoUrl || team.logo || '',
          country: team.country || '',
          drivers: Array.isArray(team.drivers) ? team.drivers : [],
          stats: {
            points: 0,
            wins: 0,
            podiums: 0,
            ...(team.stats || {})
          }
        };
        delete normalized.logo;
        return normalized;
      });
    }

    if (dataType === 'calendar') {
      const calendar = data && typeof data === 'object' ? data : { season: '2026', rounds: [] };
      return {
        ...calendar,
        season: calendar.season || '2026',
        rounds: (calendar.rounds || []).map(round => ({
          ...round,
          trackCountry: round.trackCountry || '',
          timezone: round.timezone || 'UTC',
          class: round.class || 'F1',
          streamLink: round.streamLink || ''
        }))
      };
    }

    return data;
  }

  /**
   * Экспортировать все данные в JSON
   * @returns {Object} все данные
   */
  static async exportAll() {
    return {
      drivers: await this.load('drivers'),
      teams: await this.load('teams'),
      calendar: await this.load('calendar'),
      news: await this.load('news'),
      standings: await this.load('standings'),
      results: await this.load('results'),
      exportedAt: new Date().toISOString()
    };
  }

  /**
   * Импортировать данные из JSON
   * @param {Object} data - данные для импорта
   */
  static async exportAllData() {
    return this.exportAll();
  }

  static async importAll(data) {
    try {
      if (data.drivers) await this.save('drivers', data.drivers);
      if (data.teams) await this.save('teams', data.teams);
      if (data.calendar) await this.save('calendar', data.calendar);
      if (data.news) await this.save('news', data.news);
      if (data.standings) await this.save('standings', data.standings);
      if (data.results) await this.save('results', data.results);

      console.log('✓ Все данные импортированы');
      return true;
    } catch (e) {
      console.error('Ошибка импорта:', e);
      return false;
    }
  }

  /**
   * Очистить все данные
   */
  static clearAll() {
    const keys = Object.keys(localStorage).filter(k => k.startsWith(this.PREFIX));
    keys.forEach(key => localStorage.removeItem(key));
    console.log('✓ Все данные очищены');
  }

  /**
   * Генерировать уникальный ID
   */
  static generateId(prefix = 'id') {
    return `${prefix}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }
}

// Инициализировать данные при загрузке страницы
document.addEventListener('DOMContentLoaded', async () => {
  // Загрузить демо-данные если их нет
  const drivers = await DataManager.load('drivers');
  if (drivers.length === 0) {
    console.log('Инициализация демо-данных...');
    await DataManager.initializeDemoData();
  }

  // Слушать изменения localStorage из других вкладок
  window.addEventListener('storage', (e) => {
    if (e.key && e.key.startsWith(DataManager.PREFIX)) {
      const dataType = e.key.replace(DataManager.PREFIX, '');
      console.log(`📡 Получено обновление ${dataType} из другой вкладки`);

      // Отправить событие об обновлении
      window.dispatchEvent(new CustomEvent('dataUpdated', {
        detail: {
          dataType,
          data: e.newValue ? JSON.parse(e.newValue) : null,
          timestamp: Date.now(),
          source: 'storage'
        }
      }));
    }
  });
});

/**
 * Инициализировать демо-данные
 */
DataManager.initializeDemoData = async function() {
  // Команды
  const teams = [
    {
      id: 'team_001',
      name: 'Red Velocity',
      shortName: 'RED',
      color: '#E10600',
      logoUrl: 'https://via.placeholder.com/100?text=RED',
      country: 'Germany',
      drivers: ['driver_001', 'driver_002'],
      stats: { points: 0, wins: 0 }
    },
    {
      id: 'team_002',
      name: 'Blue Storm',
      shortName: 'BLU',
      color: '#00D4FF',
      logoUrl: 'https://via.placeholder.com/100?text=BLU',
      country: 'United Kingdom',
      drivers: ['driver_003', 'driver_004'],
      stats: { points: 0, wins: 0 }
    }
  ];
  await this.save('teams', teams);

  // Пилоты
  const drivers = [
    {
      id: 'driver_001',
      firstName: 'SpeedMaster',
      lastName: 'RB',
      teamId: 'team_001',
      number: 1,
      nationality: 'RU',
      class: 'F1',
      avatar: 'https://via.placeholder.com/150?text=Driver1',
      stats: { points: 0, wins: 0, podiums: 0, fastestLaps: 0 }
    },
    {
      id: 'driver_002',
      firstName: 'ThunderKing',
      lastName: '99',
      teamId: 'team_001',
      number: 2,
      nationality: 'RU',
      class: 'F1',
      avatar: 'https://via.placeholder.com/150?text=Driver2',
      stats: { points: 0, wins: 0, podiums: 0, fastestLaps: 0 }
    },
    {
      id: 'driver_003',
      firstName: 'LightningBolt',
      lastName: '7',
      teamId: 'team_002',
      number: 3,
      nationality: 'BY',
      class: 'F1',
      avatar: 'https://via.placeholder.com/150?text=Driver3',
      stats: { points: 0, wins: 0, podiums: 0, fastestLaps: 0 }
    },
    {
      id: 'driver_004',
      firstName: 'StormChaser',
      lastName: '42',
      teamId: 'team_002',
      number: 4,
      nationality: 'KZ',
      class: 'F1',
      avatar: 'https://via.placeholder.com/150?text=Driver4',
      stats: { points: 0, wins: 0, podiums: 0, fastestLaps: 0 }
    }
  ];
  await this.save('drivers', drivers);

  // Календарь
  const calendar = {
    season: '2026',
    rounds: [
      {
        id: 'round_01',
        round: 1,
        date: '2026-05-15',
        track: 'Monaco Grand Prix',
        trackCountry: 'Monaco',
        timezone: 'Europe/Monaco',
        class: 'F1',
        status: 'upcoming',
        streamLink: 'https://twitch.tv/example'
      },
      {
        id: 'round_02',
        round: 2,
        date: '2026-06-12',
        track: 'Silverstone Circuit',
        trackCountry: 'United Kingdom',
        timezone: 'Europe/London',
        class: 'F1',
        status: 'upcoming',
        streamLink: 'https://twitch.tv/example'
      }
    ]
  };
  await this.save('calendar', calendar);

  // Новости
  const news = [
    {
      id: 'news_001',
      title: 'Начало сезона 2026!',
      content: 'Официально стартует новый сезон RFL с участием 8 пилотов.',
      category: 'Новости',
      image: 'https://via.placeholder.com/400x200?text=News1',
      date: new Date().toISOString()
    }
  ];
  await this.save('news', news);

  // Таблица чемпионата
  const standings = {
    drivers: [],
    constructors: []
  };
  await this.save('standings', standings);

  console.log('✓ Демо-данные инициализированы');
};
