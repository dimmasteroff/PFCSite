/**
 * auth.js - Аутентификация администратора
 * Использует SHA256 хеширование и sessionStorage
 */

// Подключить js-sha256 библиотеку
const ADMIN_CONFIG = {
  // SHA256('RFL2025Admin')
  passwordHash: '875e903a71a44bbb9a1408a90cbb7bf020a5f22ade74397b8e2699cc0711b4de',
  sessionKey: 'rfl_admin_session',
  sessionTimeout: 30 * 60 * 1000 // 30 минут
};

/**
 * Хеширование пароля (используем встроенный SubtleCrypto API)
 */
async function hashPassword(password) {
  const encoder = new TextEncoder();
  const data = encoder.encode(password);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  return hashHex;
}

/**
 * Вход администратора
 */
async function login(password) {
  try {
    const hash = await hashPassword(password);
    
    if (hash === ADMIN_CONFIG.passwordHash) {
      const sessionData = {
        authenticated: true,
        loginTime: Date.now(),
        expiresAt: Date.now() + ADMIN_CONFIG.sessionTimeout
      };
      sessionStorage.setItem(ADMIN_CONFIG.sessionKey, JSON.stringify(sessionData));
      console.log('✓ Вход успешен');
      return true;
    } else {
      console.error('✗ Неверный пароль');
      return false;
    }
  } catch (e) {
    console.error('Ошибка хеширования:', e);
    return false;
  }
}

/**
 * Проверить, авторизован ли администратор
 */
function isAdmin() {
  const session = sessionStorage.getItem(ADMIN_CONFIG.sessionKey);
  
  if (!session) {
    return false;
  }
  
  try {
    const sessionData = JSON.parse(session);
    
    // Проверить истечение сессии
    if (Date.now() > sessionData.expiresAt) {
      logout();
      return false;
    }
    
    return sessionData.authenticated === true;
  } catch (e) {
    console.error('Ошибка проверки сессии:', e);
    return false;
  }
}

/**
 * Выход администратора
 */
function logout() {
  sessionStorage.removeItem(ADMIN_CONFIG.sessionKey);
  console.log('✓ Выход выполнен');
  window.location.href = '/admin/login.html';
}

/**
 * Защитить страницу админа
 */
function protectAdminPage() {
  if (!isAdmin()) {
    console.warn('Доступ запрещён. Перенаправление на страницу входа...');
    window.location.href = '/admin/login.html';
  }
}

/**
 * Получить оставшееся время сессии (в минутах)
 */
function getSessionTimeRemaining() {
  const session = sessionStorage.getItem(ADMIN_CONFIG.sessionKey);
  
  if (!session) {
    return 0;
  }
  
  try {
    const sessionData = JSON.parse(session);
    const remaining = sessionData.expiresAt - Date.now();
    return Math.ceil(remaining / 1000 / 60); // в минутах
  } catch (e) {
    return 0;
  }
}

// Экспортировать функции
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { login, isAdmin, logout, protectAdminPage, getSessionTimeRemaining };
}
